package util

import mapper.UnitMap

import scala.collection.mutable.ArrayBuffer

class ConvertToWord {

  var map = new UnitMap

  def convertToWord(splitStr:ArrayBuffer[String]):String={
    val len = splitStr.length
    val word = StringBuilder.newBuilder

    for(i <- 0 to len-1){
        var ip = splitStr(i).reverse
        if(ip.length==3){
          for(i <- 0 to ip.length-1){
            if(i==0){
              word.append(map.mapUnits(ip(i).toString)+ " hundred and ")
            }
            if(i==1){
              if((ip(i)+""+ip(i+1)).toInt<20){
                word.append(map.mapUnits(ip(i)+""+ip(i+1)) +" ")
              }
              else{
                word.append(map.mapTens(ip(i).toString)+" ")
              }
            }
            if((i==2) && ((ip(i-1)+""+ip(i)).toInt>=20)){
              word.append(map.mapUnits(ip(i).toString))
            }
          }
        }

    }

    return word.toString()
  }

}
