package practice

import scala.collection.mutable.ArrayBuffer

object MyPractice {
  def main(args: Array[String]): Unit = {
    var num = new ArrayBuffer[String]()

    println(num.length)

  }

}
